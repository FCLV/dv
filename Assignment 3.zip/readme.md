Enter this folder and launch the terminal and type

```shell
python -m http.server
```

Then open Edge/Chrome and type the URL

```
localhost:8000
```



**Note:** There is a **bug** I cannot fix. Most nodes can be dragged and display the connection information when I hover on them, but some of them cannot be dragged and do not display anything when I hover on them.