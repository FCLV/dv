## Build running environment
Enter this folder and launch the terminal and type

```shell
python -m http.server
```

Then open Edge/Chrome and type the URL

```
localhost:8000
```

Choose the left option box to visualize/hide the legend, and choose the right option box to select which chart to be shown.
