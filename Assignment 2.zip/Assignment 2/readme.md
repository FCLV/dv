## Build running environment
Enter this folder and launch the terminal and type

```shell
python -m http.server
```

Then open Edge/Chrome and type the URL

```
localhost:8000
```

Move the mouse over the points to see the max&min temperature and date.

Move the mouse over the legend to see which points are between the selected duration.
